
# Functions



![](resources/images/10-functions_files/figure-docx//1MNHf8JpolaEP_vQ_kB-1xRBF9wo3haCArRu117hBoHA_g21a84b32106_0_53.png){width=100%}
