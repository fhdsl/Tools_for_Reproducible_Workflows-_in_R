
# Sharing Data



![](resources/images/10-sharing-data_files/figure-docx//1MNHf8JpolaEP_vQ_kB-1xRBF9wo3haCArRu117hBoHA_g21a84b32106_0_63.png){width=100%}
