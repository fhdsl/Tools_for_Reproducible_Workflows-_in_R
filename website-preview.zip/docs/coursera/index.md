---
title: "Course Name "
date: "February, 2022"
site: bookdown::bookdown_site
documentclass: book
bibliography: [book.bib]
biblio-style: apalike
link-citations: yes
description: "Description about Course/Book."
favicon: assets/dasl_favicon.ico
output:
    bookdown::word_document2:
      toc: true
---


# About this Course {-}
