
# Collaborations through GitHub



![](resources/images/12-collabs_files/figure-docx//1MNHf8JpolaEP_vQ_kB-1xRBF9wo3haCArRu117hBoHA_g21a84b32106_0_68.png){width=100%}
